@extends('layouts.app')
@section('title', 'Add Document Template')

@section('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
<style>
    .clause-item {
        cursor: pointer;
        transition: background-color 0.2s ease-in-out;
    }

    .clause-item:hover {
        background-color: #f1f1f1;
    }
</style>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <!-- Main Form -->

        <div class="col-md-9">
            <form action="{{ route('legal.templates.store') }}" method="POST">
                @csrf
                <div class="card shadow p-4 rounded-4 mb-3">
                    <p class="text-muted"></p>
                    <div class="card-header bg-light py-1 px-3 d-flex justify-content-between align-items-centre">
                        <h5 class="text-info mb-4"><i class="fas fa-file-alt"></i> Add New Template</h5>
                    </div>

                    <div class="mb-3">
                        <label for="TemplateName" class="form-label">Template Name</label>
                        <input type="text" name="TemplateName" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="DocumentType" class="form-label">Document Type</label>
                        <input type="text" name="DocumentType" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="Version" class="form-label">Version</label>
                        <input type="text" name="Version" class="form-control" value="v1.0">
                    </div>

                    <div class="mb-3">
                        <label for="Description" class="form-label">Description</label>
                        <textarea name="Description" class="form-control" rows="2"></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="TemplateBody" class="form-label">Template Body</label>
                        <textarea name="TemplateBody" id="editor" class="form-control" rows="10"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">💾 Save Template</button>
                </div>
            </form>
        </div>

        <!-- Clause Picker Sidebar -->
        <div class="col-md-3">
            <div class="card shadow p-3 rounded-4">
                <p class="text-muted"></p>
                <div class="card-header bg-light px-2 py-1 d-flex justify-content-between align-items-centre mb-3">
                    <h5 class="text-info mb-3"><i class="fas fa-book"></i> Clause Library</h5>
                </div>
                <input type="text" id="clause-search" class="form-control mb-2" placeholder="Search clause...">
                <div id="clause-results" style="max-height: 500px; overflow-y: auto;">
                    <p class="text-muted">Start typing to load clauses...</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
    let editor;
    ClassicEditor
        .create(document.querySelector('#editor'))
        .then(ed => editor = ed)
        .catch(error => console.error(error));

    document.getElementById('clause-search').addEventListener('input', function () {
        const q = this.value;
        if (q.length < 2) return;

        fetch(`/legal/drafts/clauses/list?q=${encodeURIComponent(q)}`)
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById('clause-results');
                container.innerHTML = '';
                data.forEach(clause => {
                    const clauseDiv = document.createElement('div');
                    clauseDiv.classList.add('clause-item', 'border', 'rounded', 'p-2', 'mb-2');
                    clauseDiv.innerHTML = `
                        <strong>${clause.ClauseTitle}</strong>
                        <p class="text-muted small">${clause.ClauseText.substring(0, 100)}...</p>
                        <button class="btn btn-sm btn-outline-primary insert-btn" data-clause="${clause.ClauseText.replace(/"/g, '&quot;')}">Insert</button>
                    `;
                    container.appendChild(clauseDiv);
                });

                document.querySelectorAll('.insert-btn').forEach(btn => {
                    btn.addEventListener('click', function () {
                        const text = this.getAttribute('data-clause');
                        insertClause(text);
                    });
                });
            });
    });

    function insertClause(text) {
        editor.model.change(writer => {
            const insertPosition = editor.model.document.selection.getFirstPosition();
            writer.insertText(text, insertPosition);
        });
    }
</script>
@endsection
